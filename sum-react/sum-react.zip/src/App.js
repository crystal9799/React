import logo from "./logo.svg";
import "./App.css";
import { useState } from "react";
import axios from "axios";

function App() {
  const [state, setState] = useState({
    message: "",
    sessionId: "",
  });
  const onSum = () => {
    axios.defaults.headers.Cookie =
      "JSESSIONID=CD6490277F32E55DFBC2C1C85147CD24;";
    axios
      .post(
        "http://localhost:8090/sum/api/sum.jsp",
        {
          withCredentials: true,
        },
        {
          headers: {
            Cookie: "JSESSIONID=CD6490277F32E55DFBC2C1C85147CD24;",
          },
        }
      )
      .then((response) => {
        console.log(response);
        console.log(response.data);
        setState(response.data);
      });
  };
  const onSumCancel = () => {};
  return (
    <div>
      <div>
        <h1>axios</h1>
        <p>{state.message}</p>
        <button onClick={onSum}>계산요청</button>
        <button onClick={onSumCancel}>계산취소</button>
      </div>
    </div>
  );
}

export default App;
